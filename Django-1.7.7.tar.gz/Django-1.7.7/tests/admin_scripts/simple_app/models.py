from ..complex_app.models.bar import Bar

__all__ = ['Bar']
